const categoryMap = [
  ['food', 'Food'],
  ['eat', 'Food'],
  ['craft', 'Craft'],
  ['culture', 'Culture'],
  ['heritage', 'Heritage'],
  ['fort', 'Heritage'],
  ['walk', 'Heritage'],
  ['story', 'Story'],
]

const cities = ['Jaipur', 'Jodhpur', 'Udaipur', 'Jaisalmer', 'Varanasi', 'Agra', 'Hampi']

export function interpretQuery(query = '') {
  const normalized = query.trim()
  const lower = normalized.toLowerCase()
  const durationMatch = lower.match(/(\d+(?:\.\d+)?)\s*(?:hour|hours|hr|hrs)/)
  const budgetMatch = lower.match(/(?:under|below|budget|₹|rs\.?|inr)\s*₹?\s*([\d,]+)/i)
  const destination = cities.find((city) => lower.includes(city.toLowerCase())) || 'Jaipur'
  const matchedCategory = categoryMap.find(([term]) => lower.includes(term))
  const category = matchedCategory?.[1] || 'Heritage'
  const duration = durationMatch ? `${durationMatch[1]} ${Number(durationMatch[1]) === 1 ? 'hour' : 'hours'}` : '2 hours'
  const maxBudget = budgetMatch ? Number(budgetMatch[1].replace(/,/g, '')) : 1000
  const preference = /authentic|local|traditional|quiet|family/i.exec(normalized)?.[0] || 'Authentic'
  return { raw: normalized || 'I want an authentic heritage experience in Jaipur for 2 hours under ₹1000', destination, category, duration, durationHours: Number(durationMatch?.[1] || 2), maxBudget, preference: preference[0].toUpperCase() + preference.slice(1).toLowerCase() }
}

export function matchesQuery(item, interpretation) {
  const categoryMatches = interpretation.category === 'Heritage' ? ['Heritage', 'Culture walk', 'Palace tour', 'Food & culture'].some((value) => item.category.includes(value)) : item.category.toLowerCase().includes(interpretation.category.toLowerCase()) || item.tags.some((tag) => tag.toLowerCase() === interpretation.category.toLowerCase())
  const durationHours = Number.parseFloat(item.duration)
  return item.city.toLowerCase() === interpretation.destination.toLowerCase() && categoryMatches && item.price <= interpretation.maxBudget && durationHours <= interpretation.durationHours + 1
}
