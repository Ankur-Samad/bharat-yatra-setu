import { BrowserRouter, Route, Routes } from 'react-router-dom'
import { LandingPage, AdminDashboard, ProviderDashboard, ProviderSimplePage, ProviderTrustPage, ProviderVoicePage } from './pages'
import { BookingPage, BookingSuccessPage, DiscoverPage, ExperienceDetailsPage, MyBookingsPage, PaymentPage } from './touristPages'
import { ProviderPage } from './providerPage'
import './App.css'

function Placeholder({ title }) {
  return <div className="route-placeholder"><a className="brand" href="/"><span className="brand-mark">✦</span><span>BHARAT YATRA <b>SETU</b></span></a><span className="placeholder-mark">◌</span><div className="eyebrow">PROTOTYPE ROUTE</div><h1>{title}</h1><p>This screen is queued for the next product slice. The route and navigation are active in the prototype.</p><a className="button" href="/explore">Return to discovery <span>↗</span></a></div>
}

function App() {
  return <BrowserRouter><Routes>
    <Route path="/" element={<LandingPage />} />
    <Route path="/explore" element={<DiscoverPage />} />
    <Route path="/discover" element={<DiscoverPage />} />
    <Route path="/experience/:id" element={<ExperienceDetailsPage />} />
    <Route path="/booking/:id" element={<BookingPage />} />
    <Route path="/payment/:id" element={<PaymentPage />} />
    <Route path="/booking-success/:bookingId" element={<BookingSuccessPage />} />
    <Route path="/provider" element={<ProviderPage />} />
    <Route path="/bookings" element={<MyBookingsPage />} />
    <Route path="/saved" element={<Placeholder title="Your saved connections." />} />
    <Route path="/profile" element={<Placeholder title="Your traveller profile." />} />
    <Route path="/provider/register" element={<ProviderSimplePage eyebrow="PROVIDER ONBOARDING" title={<>Bring your local story to the <em>network.</em></>} />} />
    <Route path="/provider/dashboard" element={<ProviderDashboard />} />
    <Route path="/provider/trust" element={<ProviderTrustPage />} />
    <Route path="/provider/voice" element={<ProviderVoicePage />} />
    <Route path="/provider/experiences" element={<ProviderSimplePage eyebrow="EXPERIENCES" title={<>Make your listing <em>discoverable.</em></>} />} />
    <Route path="/provider/bookings" element={<ProviderSimplePage eyebrow="BOOKINGS" title={<>Your next welcome is <em>already here.</em></>} />} />
    <Route path="/provider/availability" element={<ProviderSimplePage eyebrow="AVAILABILITY" title={<>Keep the door <em>open.</em></>} />} />
    <Route path="/provider/earnings" element={<ProviderSimplePage eyebrow="EARNINGS" title={<>See what stays <em>local.</em></>} />} />
    <Route path="/admin" element={<AdminDashboard />} />
    <Route path="/admin/verification" element={<AdminDashboard verification />} />
    <Route path="/admin/providers" element={<AdminDashboard verification />} />
    <Route path="/admin/bookings" element={<AdminDashboard />} />
    <Route path="/admin/revenue" element={<AdminDashboard />} />
    <Route path="/admin/impact" element={<AdminDashboard />} />
    <Route path="*" element={<Placeholder title="This route is not in the prototype yet." />} />
  </Routes></BrowserRouter>
}

export default App
